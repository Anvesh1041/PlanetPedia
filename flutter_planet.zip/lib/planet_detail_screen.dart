import 'package:flutter/material.dart';

class PlanetDetailScreen extends StatelessWidget {
  final String planetName;
  final String description;
  final String planetImg;

  const PlanetDetailScreen({
    Key? key,
    required this.planetName,
    required this.description,
    required this.planetImg, // Added planetImg variable
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Planet Details'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xff1E72BA),
              Color(0xff2c1f6e),
            ],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Display planet image
              Image.asset(
                planetImg,
                width: 150, // Adjust width as needed
                height: 150, // Adjust height as needed
              ),
              SizedBox(height: 20),
              Text(
                'Details for $planetName',
                style: TextStyle(fontSize: 24),
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  getDescription(),
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String getDescription() {
    switch (planetName.toLowerCase()) {
      case 'earth':
        return 'Earth is the third planet from the Sun and the only astronomical object known to harbor life. It is home to millions of species, including humans. Earth has a diverse range of ecosystems and climates, ranging from deserts to rainforests. It has one natural satellite, the Moon, which plays a significant role in regulating tides and stabilizing Earth\'s rotation.';
      case 'mars':
        return 'Mars is often called the "Red Planet" due to its reddish appearance. Mars is the fourth planet from the Sun and the second smallest planet in the Solar System. It has surface features reminiscent of both the impact craters of the Moon and the volcanoes, valleys, deserts, and polar ice caps of Earth. Mars is a terrestrial planet with a thin atmosphere composed primarily of carbon dioxide.';
      case 'jupiter':
        return 'Jupiter is the largest planet in our Solar System, known for its massive size and distinct striped appearance. It is a gas giant composed mostly of hydrogen and helium. Jupiter has a strong magnetic field and dozens of moons, including the four largest moons known as the Galilean moons: Io, Europa, Ganymede, and Callisto. The Great Red Spot, a giant storm that has been raging for centuries, is one of Jupiter\'s most prominent features.';
      case 'saturn':
        return 'Saturn is the sixth planet from the Sun and the second largest in the Solar System, after Jupiter. It is a gas giant with an average radius about nine times that of Earth. Saturn is known for its prominent ring system, which consists of nine continuous main rings and three discontinuous arcs. The planet has a pale yellow hue due to ammonia crystals in its upper atmosphere. Saturn has 82 known moons, including Titan, which is larger than the planet Mercury and is the only moon in the Solar System with a substantial atmosphere.';
      case 'uranus':
        return 'Uranus is the seventh planet from the Sun and the third largest in terms of planetary radius and fourth largest in terms of planetary mass in the Solar System. It is often referred to as an "ice giant" planet. Uranus has a unique feature among the planets - it rotates on its side, with an axial tilt of over 90 degrees. This gives it extreme seasons, with each pole getting around 42 years of continuous sunlight followed by 42 years of darkness. Uranus has a faint planetary ring system and 27 known moons.';
      case 'neptune':
        return 'Neptune is the eighth and farthest known planet from the Sun in the Solar System. It is a gas giant and is often referred to as an "ice giant" due to its high content of icy materials. Neptune has a vivid blue coloration, primarily due to the presence of methane in its atmosphere. It has the strongest sustained winds of any planet in the Solar System, with wind speeds reaching up to 2,100 kilometers per hour (1,300 mph). Neptune has a faint planetary ring system and 14 known moons, the largest of which is Triton.';
      case 'mercury':
        return 'Mercury is the smallest and innermost planet in the Solar System. It is named after the Roman deity Mercury, the messenger of the gods. Mercury is one of the four terrestrial planets and is composed mostly of silicate rock and metals. It has a heavily cratered surface with long, winding scarps and ridges, indicating significant tectonic activity in the past. Mercury has no atmosphere to retain heat, resulting in extreme temperature variations between its day and night sides.';
      case 'venus':
        return 'Venus is the second planet from the Sun and is often called Earth\'s "sister planet" due to their similar size, composition, and proximity. It is named after the Roman goddess of love and beauty. Venus has a thick atmosphere composed mainly of carbon dioxide, with clouds of sulfuric acid. It has the hottest surface of any planet in the Solar System, with temperatures reaching up to 900 degrees Fahrenheit (475 degrees Celsius). Venus has no moons and rotates in the opposite direction to most planets.';
      default:
        return 'Description not available';
    }
  }
}
