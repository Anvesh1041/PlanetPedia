package com.example.flutter_planet_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
